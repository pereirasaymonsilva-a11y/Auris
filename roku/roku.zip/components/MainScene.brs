sub init()
    m.cover = m.top.findNode("cover")
    m.title = m.top.findNode("title")
    m.artist = m.top.findNode("artist")
    m.album = m.top.findNode("album")
    m.status = m.top.findNode("status")
    m.lyrics = m.top.findNode("lyrics")
    m.player = m.top.findNode("player")

    showIdleState()

    ' Pega os parâmetros enviados pelo Android
    input = CreateObject("roInput")
    params = input.GetInfo()

    if params.DoesExist("ws") then
        wsUrl = params.ws
        connectWebSocket(wsUrl)
    else
        m.status.text = "WS ausente"
    end if
end sub

sub connectWebSocket(wsUrl as String)
    m.status.text = "Conectando..."

    m.socket = CreateObject("roWebSocket")

    m.socket.ObserveField("message", "onSocketMessage")
    m.socket.ObserveField("close", "onSocketClosed")
    m.socket.ObserveField("error", "onSocketError")

    success = m.socket.SetUrl(wsUrl)

    if success then
        m.socket.Connect()
    else
        m.status.text = "WS inválido"
    end if
end sub

sub onSocketMessage()
    message = m.socket.message
    if message = invalid or message = "" then return

    data = ParseJson(message)
    if data = invalid then return

    msgType = getStringField(data, "type", "")

    if msgType = "play" then
        handlePlayMessage(data)
    else if msgType = "stop" then
        m.player.control = "stop"
        showIdleState()
    else if msgType = "seek" then
        position = data.position
        m.player.seek = position
    end if
end sub

sub handlePlayMessage(data as Object)
    m.title.text = getStringField(data, "title", "Sem título")
    m.artist.text = getStringField(data, "artist", "Sem artista")
    m.album.text = getStringField(data, "album", "")
    m.lyrics.text = getStringField(data, "lyrics", "")
    m.status.text = "Tocando"

    coverUrl = getStringField(data, "cover", "")
    if coverUrl <> "" then
        m.cover.uri = coverUrl
    end if

    streamUrl = getStringField(data, "url", "")
    mimeType = getStringField(data, "mime", "audio/mpeg")

    if streamUrl <> "" then
        playStream(streamUrl, mimeType, data)
    else
        m.status.text = "Stream ausente"
    end if
end sub

sub playStream(streamUrl as String, mimeType as String, data as Object)
    content = CreateObject("roSGNode", "ContentNode")

    content.url = streamUrl
    content.streamformat = getStreamFormat(mimeType)

    content.title = getStringField(data, "title", "Auris")
    content.description = getStringField(data, "artist", "") + " - " + getStringField(data, "album", "")

    cover = getStringField(data, "cover", "")
    content.hdPosterUrl = cover
    content.fhdPosterUrl = cover

    m.player.content = content
    m.player.control = "play"
end sub

sub onSocketClosed()
    m.status.text = "Desconectado"
end sub

sub onSocketError()
    m.status.text = "Erro WebSocket"
end sub

sub showIdleState()
    m.title.text = "Auris Receiver"
    m.artist.text = "Aguardando conexão..."
    m.album.text = ""
    m.status.text = "Esperando"
    m.lyrics.text = ""
    m.cover.uri = ""
end sub

function getStreamFormat(mimeType as String) as String
    mime = LCase(mimeType)

    if InStr(1, mime, "audio/mpeg") > 0 then return "mp3"
    if InStr(1, mime, "audio/mp4") > 0 then return "mp4"
    if InStr(1, mime, "audio/aac") > 0 then return "mp4"
    if InStr(1, mime, "video/mp4") > 0 then return "mp4"
    if InStr(1, mime, "application/x-mpegurl") > 0 then return "hls"
    if InStr(1, mime, "application/vnd.apple.mpegurl") > 0 then return "hls"

    return "mp3"
end function

function getStringField(obj as Object, fieldName as String, fallback as String) as String
    if obj = invalid then return fallback

    if obj.DoesExist(fieldName) and obj[fieldName] <> invalid then
        return obj[fieldName].ToStr()
    end if

    return fallback
end function

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press and key = "back" then
        m.player.control = "stop"
        return false
    end if

    return false
end function